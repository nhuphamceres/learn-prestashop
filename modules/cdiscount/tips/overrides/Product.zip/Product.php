<?php

/*
 * Installation :
 * Copy the current file into prestashop/overrides/classes directory
 * Remove the cache file : prestashop/cache/class_index.php 
 * Fill the functions with your needs
 */

class Product extends ProductCore
{
    public static function externalDescription($id_lang, $id_product, $is_marketing_description = false)
    {
        $description = 'Champ Description Externe';

        return ($description);
    }

    public static function externalName($id_lang, $id_product, $id_product_combination, $name_short = false)
    {
        $name = 'Champ Nom du produit externe';

        return ($name);
    }
}
